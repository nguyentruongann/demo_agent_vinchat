from __future__ import annotations

import src.backend.services.query_parser as query_parser


def _parse_without_catalog(monkeypatch, user_message: str, rag_query: str):
    monkeypatch.setattr(query_parser, "detect_destinations", lambda _text: [])
    return query_parser.parse_retrieval_query(user_message, rag_query)


def test_open_ended_travel_discovery_does_not_become_rewrite_hotel(monkeypatch):
    parsed = _parse_without_catalog(
        monkeypatch,
        "có nơi nào có cảnh rừng núi thiên nhiên để đi du lịch không ạ",
        "Vinpearl destinations and resorts with natural mountain and forest landscapes",
    )

    assert parsed["intent_origin"] == "generic_discovery"
    assert parsed["explicit_intents"] == []
    assert parsed["intents"] == list(query_parser.GENERIC_DISCOVERY_INTENTS)


def test_open_ended_where_request_is_discovery_even_without_destination(monkeypatch):
    parsed = _parse_without_catalog(
        monkeypatch,
        "có nơi nào có rừng núi thiên nhiên đẹp không bạn",
        "Vinpearl destinations with beautiful natural forests and mountains",
    )

    assert parsed["intent_origin"] == "generic_discovery"
    assert "hotel" in parsed["intents"]
    assert "attraction" in parsed["intents"]


def test_specific_explicit_intent_still_wins(monkeypatch):
    parsed = _parse_without_catalog(
        monkeypatch,
        "Giới thiệu ngắn về sân golf Cape Wickham Golf Links",
        "Short introduction to Cape Wickham Golf Links golf course",
    )

    assert parsed["intent_origin"] == "current_explicit"
    assert parsed["intents"] == ["golf"]


def test_weak_visit_word_does_not_force_generic_discovery_without_destination(monkeypatch):
    parsed = _parse_without_catalog(
        monkeypatch,
        "Can I visit with a pet?",
        "Can I visit Grand World Phu Quoc with a pet?",
    )

    assert parsed["intent_origin"] != "generic_discovery"
